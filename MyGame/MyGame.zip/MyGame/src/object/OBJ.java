package object;

public interface OBJ extends Cloneable{

    public OBJ makeCopy();

}
