package Data;

import java.io.Serializable;

public class DataStorage implements Serializable {
    //player stats
    int level;
    int maxLife;
    int maxMana;
    int mana;
    int life;
    int coins;
    int currentMap;


}
